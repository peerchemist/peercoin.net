$lang['en'] += array(
	//Whitepaper
	'whitepaper.download_pdf' => 'Download PDF',
	'whitepaper.software' => 'The whitepapers are available in Portable Document Format (PDF). Please use your preferred <a href="http://pdfreaders.org/">software for reading</a>.',

);