$lang['en'] += array(
	'waldownload.download' => 'Download',
	'waldownload.source' => 'Source Code',
	'waldownload.license' => 'License',
	'waldownload.other_platforms' => 'Other platforms',
	'waldownload.signatures' => 'Signatures',
	'waldownload.qt_title' => 'Peercoin-QT',
	'waldownload.peerunity_title' => 'Peerunity',	
);