$lang['en'] += array(
	// Global
	'homepage_title' => '﻿Peercoin - Secure & Sustainable Cryptocoin.',

	'second_ago' => 'second ago',
	'seconds_ago' => 'seconds ago',

	'website' => 'Website',
	'forum' => 'Forum',
);