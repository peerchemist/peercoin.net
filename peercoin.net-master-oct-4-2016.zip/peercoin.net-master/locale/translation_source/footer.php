$lang['en'] += array(
	'footer.links' => 'Links',
	'footer.tools' => 'Tools',
	'footer.exchanges' => 'Exchanges',
	'footer.mining' => 'Mining',
);