﻿<?php

include("languages/ar.php");
include("languages/de.php");
include("languages/en.php");
include("languages/es.php");
include("languages/fr.php");
include("languages/hi_IN.php");
include("languages/id.php");
include("languages/it.php");
include("languages/no.php");
include("languages/ru.php");
include("languages/tl_PH.php");
include("languages/zh.php");
include("languages/pt_BR.php");
include("languages/el_GR.php");