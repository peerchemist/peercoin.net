<?php

$locale_languages = array(
	'ar'    =>  'العربية',
	'id'    =>  'Bahasa Indonesia',
	'pt_BR' =>  'Brazilian portuguese',
	'zh'	=>  '中文',
	'de'    =>  'Deutsch',
	'el_GR' =>  'ελληνικά',
	'es'    =>  'Español',
	'en'	=>  'English',
	'fr'	=>  'Français',
	'hi_IN'	=>  'हिन्दी',
	'it'    =>  'Italiano',
	'no'	=>  'Norsk',
	'ru'    =>  'Русский',
	'tl_PH' =>  'Tagalog (Philippines)',
);
