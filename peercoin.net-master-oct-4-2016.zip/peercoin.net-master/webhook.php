<?php

// Git Pull
system("git pull");

?>
